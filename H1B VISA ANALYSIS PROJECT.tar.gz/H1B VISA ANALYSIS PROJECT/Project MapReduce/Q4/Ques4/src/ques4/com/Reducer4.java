package ques4.com;

import java.io.IOException;
import java.util.TreeMap;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reducer4 extends Reducer<Text, Text, NullWritable, Text>
{
	TreeMap<Integer, Text> map = new TreeMap<Integer,Text>();
	@Override
	protected void reduce(Text key, Iterable<Text> values,Context context)throws IOException, InterruptedException 
	{
		int sum = 0;
		String year = "";
		for(Text val : values)
		{
			String[] token = val.toString().split(",");
			year = token[0];
			int count = Integer.parseInt(token[1]);
			
			sum += count;
		}
		
		String employee_name = key.toString();
		String myValue = year+ ","+employee_name + "," + sum;
		
		map.put(new Integer(sum), new Text(myValue));
		if(map.size() > 5)
		{
			map.remove(map.firstKey());
		}
	}
	@Override
	protected void cleanup(Context context)throws IOException, InterruptedException 
	{
		for(Text top5 : map.descendingMap().values())
		{
			context.write(NullWritable.get(), top5);
		}
	}
	
	
	
} 