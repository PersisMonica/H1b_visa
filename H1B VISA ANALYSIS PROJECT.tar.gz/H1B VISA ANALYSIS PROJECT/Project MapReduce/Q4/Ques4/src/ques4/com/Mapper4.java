package ques4.com;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper4 extends Mapper<LongWritable, Text, Text, Text>
{
	LongWritable one = new LongWritable(1);
	
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
	{
		String[] record = value.toString().split("\t");
		String year = record[7];
		String employee_name = record[2];
		
		String myVal = year+ ","+one;
		
		context.write(new Text(employee_name), new Text(myVal));
	}
	
} 