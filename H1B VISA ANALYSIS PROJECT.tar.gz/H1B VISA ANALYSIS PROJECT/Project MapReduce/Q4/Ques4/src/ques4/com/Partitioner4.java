package ques4.com;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class Partitioner4 extends Partitioner<Text, Text>
{

	@Override
	public int getPartition(Text key, Text value, int numReduceTasks) {
	
		String[] str = value.toString().split(",");
		
		String year = str[0];
		
		if(year.equals("2011"))
		{
			return 0 % numReduceTasks;
		}
		else if(year.equals("2012"))
		{
			return 1 % numReduceTasks;
		}
		else if(year.equals("2013"))
		{
			return 2 % numReduceTasks;
		}
		else if(year.equals("2014"))
		{
			return 3 % numReduceTasks;
		}
		else if(year.equals("2015"))
		{
			return 4 % numReduceTasks;
		}
		else
		{
			return 5 % numReduceTasks;
		}
	}
	
}
 