package ques7.com;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper7 extends Mapper <LongWritable, Text, Text, IntWritable>
{

	@Override
	protected void map(LongWritable key, Text value, Context context)throws IOException, InterruptedException 
	{
		String[] str = value.toString().split("\t");
		String year = str[7];
		
		context.write(new Text(year), new IntWritable(1));
	}

}
