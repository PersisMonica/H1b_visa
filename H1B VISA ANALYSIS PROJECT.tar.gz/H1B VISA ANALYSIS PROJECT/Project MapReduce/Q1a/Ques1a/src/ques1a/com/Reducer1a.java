package ques1a.com;

import java.io.IOException;
import java.util.TreeMap;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Reducer; 

public  class Reducer1a extends Reducer<Text, IntWritable, Text, DoubleWritable>
{
	String[] years = {"2011","2012","2013","2014","2015","2016"};
	double[] arr = new double[6];
	TreeMap<String,Double> map = new TreeMap<String,Double>();
	int i = 0;
	@Override
	protected void reduce(Text key, Iterable<IntWritable> values,Context context)throws IOException, InterruptedException 
	{
		int sum =0;
		
		for(IntWritable val : values)
		{
			sum += val.get();
		}
		
		arr[i++] = sum;
		
	}
	@Override
	protected void cleanup(Context context)throws IOException, InterruptedException 
	{
		double avg = 0.0;
		double sum1 = 0.0;
		for(int i=0; i<6; i++ )
		{
			/*if(i == 0)
			{
				context.write(new Text(years[i]), new DoubleWritable(0));
			}
			else
			{
				context.write(new Text(years[i]), new DoubleWritable((arr[i]-arr[i-1])/arr[i-1]*100));
			}*/
			try {
				sum1 += (arr[i]-arr[i-1])/arr[i-1]*100;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
		}
		avg = sum1 /5;
		context.write(new Text("Data Engineer Average Growth For Five Years"), new DoubleWritable(avg));
	}
	
	
	
}
