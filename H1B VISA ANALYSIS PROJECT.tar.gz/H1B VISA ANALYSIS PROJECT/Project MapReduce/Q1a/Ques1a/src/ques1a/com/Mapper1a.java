package ques1a.com;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper1a extends Mapper<LongWritable, Text, Text, IntWritable>
{
	Text myKey = new Text();
	IntWritable one = new IntWritable(1);
	
	@Override
	protected void map(LongWritable key, Text value, Context context)throws IOException, InterruptedException 
	{
		String[] record = value.toString().split("\t");
		
		String job_title = record[4];
		
		String year = record[7];
		
		if(job_title.contains("DATA ENGINEER") && job_title != null)
		{
			String str = "DATA ENGINEER"+","+year;
			
			myKey.set(str);
			
			context.write(myKey, one);
		}
	}
	
}
