package ques3.com;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper3 extends Mapper <LongWritable, Text, Text, LongWritable>
{

	protected void map(LongWritable key, Text value, Context context)throws IOException, InterruptedException 
	{
		
		String[] str = value.toString().split("\t");
		String soc_name = str[3];
		String job = str[4];
		String status = str[1];
	    if (job.contains("DATA SCIENTIST") && status.equals("CERTIFIED"))
	    {
	    	context.write(new Text(soc_name), new LongWritable(1));
	    }
	    
	    
	}
}
