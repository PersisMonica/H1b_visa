package ques3.com;

import java.io.IOException;
import java.util.TreeMap;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reducer3 extends Reducer <Text, LongWritable,NullWritable,Text>
{
	TreeMap<Long,Text> record = new TreeMap<Long,Text>();
	
	public void reduce(Text key, Iterable<LongWritable> values, Context context)throws IOException, InterruptedException
	{
		int sum = 0;
		String myValue = "";
		String mySum = "";
		
		for(LongWritable val : values)
		{
			sum += val.get();
		}
		
		myValue = key.toString();
		mySum = String.format("%d", sum);
		myValue = myValue + ',' + mySum;
		
		record.put(new Long(sum),new Text(myValue));
		
		if(record.size() > 1)
		{
			record.remove(record.firstKey());
		}
	}

  
 protected void cleanup(Context context) throws IOException,InterruptedException
 {
	 for(Text t : record.descendingMap().values())
	 {
		 context.write(NullWritable.get(), t);
	 }
 }


}




